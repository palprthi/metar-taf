const express = require('express');
const fetch = require('node-fetch');
const app = express();
const port = process.env.PORT || 3000;

const API_KEY = 'j--pEsvqUuUJXgSW-t6K0omwYa5X9FHCQBO5lf4gue4';

app.use(express.static('public'));

app.get('/api/metar/:icao', async (req, res) => {
  const icao = req.params.icao.toUpperCase();
  const response = await fetch(`https://avwx.rest/api/metar/${icao}?format=json`, {
    headers: { Authorization: `Bearer ${API_KEY}` }
  });
  const data = await response.json();
  res.json(data);
});

app.get('/api/taf/:icao', async (req, res) => {
  const icao = req.params.icao.toUpperCase();
  const response = await fetch(`https://avwx.rest/api/taf/${icao}?format=json`, {
    headers: { Authorization: `Bearer ${API_KEY}` }
  });
  const data = await response.json();
  res.json(data);
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
